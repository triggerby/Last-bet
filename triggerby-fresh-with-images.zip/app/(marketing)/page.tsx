
"use client";
import Hero from "@/components/Hero"; import Automations from "@/components/Automations"; import CtaStrip from "@/components/CtaStrip"; import AiOverlay from "@/components/AiOverlay";
export default function Page(){ return (<main><Hero/><Automations/><div id="cta"><CtaStrip/></div><AiOverlay/></main>); }
