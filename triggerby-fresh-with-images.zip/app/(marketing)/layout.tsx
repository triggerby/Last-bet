
export const metadata = { title: "TriggerBy — AI Automation for Shopify" };
import "./../globals.css"; import React from "react";
export default function RootLayout({children}:{children:React.ReactNode}){
  return (<html lang="en"><body className="bg-black text-white antialiased">
    <header className="sticky top-0 z-40 border-b border-white/10 bg-black/60 backdrop-blur">
      <div className="mx-auto max-w-7xl px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3"><div className="h-8 w-8 rounded bg-brand.green"/><span className="text-sm font-semibold">TriggerBy</span></div>
        <a href="#cta" className="rounded-lg bg-brand.green px-4 py-2 text-black text-sm font-semibold">Get My AI Roadmap</a>
      </div>
    </header>
    {children}
    <footer className="border-t border-white/10 py-12 mt-24"><div className="mx-auto max-w-7xl px-6 text-sm opacity-70">© {new Date().getFullYear()} TriggerBy</div></footer>
  </body></html>);
}
