
import { NextRequest, NextResponse } from "next/server";
export async function POST(req: NextRequest){ const {email,url}=await req.json(); if(!email||!url) return NextResponse.json({error:"email and url required"},{status:400}); console.log("Audit requested",{email,url,ts:Date.now()}); return NextResponse.json({ok:true}); }
