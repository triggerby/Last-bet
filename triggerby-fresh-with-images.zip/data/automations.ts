export type Automation = { id:string; title:string; kpi:string; oneLiner:string; image:string; badge?:string; ctaLabel?:string; ctaHref?:string; };
export const automations: Automation[] = [
  {
    "id": "cart-recovery-engine",
    "title": "Cart Recovery Engine",
    "kpi": "Recover 8\u201315% lost carts",
    "oneLiner": "Cross-channel nudges that feel human.",
    "image": "/images/automations/cart-recovery-engine.png"
  },
  {
    "id": "where-is-my-order",
    "title": "Where Is My Order (WISMO)",
    "kpi": "Tickets \u2193 30\u201360%",
    "oneLiner": "Instant order-status answers by email/SMS/chat. Deflects support and boosts CSAT.",
    "image": "/images/automations/where-is-my-order.png"
  },
  {
    "id": "ad-budget-optimizer",
    "title": "Ad Budget Optimizer",
    "kpi": "Spend \u2192 winners",
    "oneLiner": "Daily budget rebalancing by marginal ROAS.",
    "image": "/images/automations/ad-budget-optimizer.png"
  },
  {
    "id": "attribution-protector",
    "title": "Attribution Protector",
    "kpi": "ROAS you trust",
    "oneLiner": "De-dupe events and patch tracking gaps.",
    "image": "/images/automations/attribution-protector.png"
  },
  {
    "id": "aov-booster",
    "title": "Aov Booster",
    "kpi": "AOV +10\u201320%",
    "oneLiner": "Personalized bundles and post-purchase offers.",
    "image": "/images/automations/aov-booster.png"
  },
  {
    "id": "profit-maximizer",
    "title": "Profit Maximizer",
    "kpi": "Margin \u2191",
    "oneLiner": "Smart pricing with contribution-margin guardrails.",
    "image": "/images/automations/profit-maximizer.png"
  },
  {
    "id": "fraud-shield",
    "title": "Fraud Shield",
    "kpi": "False positives \u2193",
    "oneLiner": "Risk scoring with rules + ML.",
    "image": "/images/automations/fraud-shield.png"
  },
  {
    "id": "loss-preventer",
    "title": "Loss Preventer",
    "kpi": "Leakage \u2193",
    "oneLiner": "Catches discount abuse and failed payments.",
    "image": "/images/automations/loss-preventer.png"
  },
  {
    "id": "chargeback-winner",
    "title": "Chargeback Winner",
    "kpi": "Win rate \u2191",
    "oneLiner": "Auto-collects evidence and files disputes.",
    "image": "/images/automations/chargeback-winner.png"
  },
  {
    "id": "inventory-guard",
    "title": "Inventory Guard",
    "kpi": "Stockouts \u2193",
    "oneLiner": "Forecasts demand and routes inventory.",
    "image": "/images/automations/inventory-guard.png"
  }
];
