
import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: { extend: { colors: { brand: { green: "#00C58E", dark: "#0A0F0D" } } } },
  plugins: [],
};
export default config;
