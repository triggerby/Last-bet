
import Link from "next/link";
export default function Hero(){
  return (<section className="py-28 bg-gradient-to-b from-black to-brand.dark">
    <div className="mx-auto max-w-7xl px-6">
      <p className="text-brand.green text-xs font-semibold tracking-widest uppercase">TriggerBy</p>
      <h1 className="mt-3 text-4xl md:text-5xl font-bold">AI Automation for Shopify</h1>
      <p className="mt-4 max-w-2xl opacity-80">Set it once. Watch it earn—every day. 10 proven machines and custom AI for scale.</p>
      <div className="mt-8 flex gap-3 flex-col sm:flex-row">
        <Link href="#cta" className="rounded-lg bg-brand.green px-5 py-3 text-black text-sm font-semibold">Get My AI Roadmap</Link>
        <Link href="#automations" className="rounded-lg border border-white/20 px-5 py-3 text-sm">See the Automations</Link>
      </div>
    </div>
  </section>);
}
