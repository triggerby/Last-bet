
export default function CtaStrip(){ return (<section className="py-16"><div className="mx-auto max-w-7xl px-6 rounded-2xl glass p-8">
  <div className="grid md:grid-cols-[1fr_auto] items-center gap-6"><div><h3 className="text-xl font-semibold">Discover Your Hidden Revenue Machine</h3><p className="text-sm opacity-80 mt-2">Free audit. Actionable plan in under 30 minutes.</p></div>
  <a href="#ai-overlay" className="rounded-lg bg-brand.green px-5 py-3 text-black text-sm font-semibold">Get My AI Roadmap</a></div></div></section>); }
