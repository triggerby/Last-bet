
"use client";
import { automations } from "@/data/automations"; import Image from "next/image"; import useEmblaCarousel from "embla-carousel-react"; import { useEffect } from "react";
function Carousel({ items }:{ items: typeof automations }){
  const [emblaRef, emblaApi] = useEmblaCarousel({ loop:true, align:"start" });
  useEffect(()=>{ if(emblaApi){ } },[emblaApi]);
  if(items.length===0) return <p className="opacity-70">Cards will appear here as we add them.</p>;
  return (<div className="overflow-hidden" ref={emblaRef}><div className="flex gap-6">
    {items.map(a=>(<div key={a.id} className="min-w-[280px] md:min-w-[360px] rounded-xl border border-white/10 p-5 bg-white/[0.02]">
      <div className="relative h-40 w-full overflow-hidden rounded-lg mb-4"><Image src={a.image} alt={a.title} fill className="object-cover"/></div>
      <h3 className="text-lg font-semibold">{a.title}</h3><p className="text-sm opacity-80 mt-1">{a.oneLiner}</p><p className="text-xs mt-2 text-brand.green">{a.kpi}</p>
    </div>))}
  </div></div>);
}
export default function Automations(){
  const set1 = automations.slice(0,3); const set2 = automations.slice(3,7); const set3 = automations.slice(7,10);
  return (<section id="automations" className="py-24 bg-black"><div className="mx-auto max-w-7xl px-6">
    <h2 className="text-2xl md:text-3xl font-bold">10 Prebuilt Automations for Shopify</h2>
    <div className="mt-8 space-y-10"><Carousel items={set1}/><Carousel items={set2}/><Carousel items={set3}/></div>
  </div></section>);
}
