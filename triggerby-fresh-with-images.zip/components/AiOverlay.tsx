
"use client";
import { useEffect, useState } from "react"; import Image from "next/image";
export default function AiOverlay(){ const [open,setOpen]=useState(false); const [seen,setSeen]=useState(false);
  const [email,setEmail]=useState(""); const [url,setUrl]=useState(""); const [status,setStatus]=useState<string|null>(null);
  useEffect(()=>{ const onScroll=()=>{ if(!seen){ setOpen(true); setSeen(true); window.removeEventListener("scroll",onScroll);} };
    window.addEventListener("scroll",onScroll,{once:true}); return ()=>window.removeEventListener("scroll",onScroll);},[seen]);
  async function submit(e:React.FormEvent){ e.preventDefault(); setStatus("Submitting...");
    try{ const r=await fetch("/api/audit",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email,url})}); const j=await r.json();
      if(!r.ok) throw new Error(j.error||"Failed"); setStatus("Audit scheduled. Delivery in < 30 minutes."); }catch(err:any){ setStatus(err.message);} }
  if(!open) return null;
  return (<div id="ai-overlay" className="fixed inset-0 z-50 flex items-center justify-center px-4"><div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={()=>setOpen(false)}/>
    <div className="relative glass max-w-2xl w-full p-6"><div className="flex items-center gap-4">
      <div className="relative h-20 w-20 overflow-hidden rounded-xl"><Image src="/images/agent/agent.jpg" alt="TriggerBy AI Agent" fill className="object-cover"/></div>
      <div><h3 className="text-xl font-semibold">TriggerBy AI Agent for Shopify</h3><p className="text-sm opacity-80">Transparent glass UI. Enter store URL and email. Receive a diagnostic in 30 minutes.</p></div></div>
      <form onSubmit={submit} className="mt-5 grid md:grid-cols-[1fr_1fr_auto] gap-3">
        <input required type="url" placeholder="Store URL" value={url} onChange={e=>setUrl(e.target.value)} className="rounded-md bg-white/5 px-3 py-3 border border-white/15"/>
        <input required type="email" placeholder="Your email" value={email} onChange={e=>setEmail(e.target.value)} className="rounded-md bg-white/5 px-3 py-3 border border-white/15"/>
        <button className="rounded-md bg-brand.green text-black px-5 py-3 font-semibold text-sm">Analyze My Store</button></form>
      {status && <p className="mt-3 text-sm opacity-80">{status}</p>}</div></div>); }
