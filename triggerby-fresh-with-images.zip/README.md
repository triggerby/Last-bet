
# TriggerBy — fresh scaffold
- Next 14 + Tailwind + Embla + Framer Motion
- Carousels slice 3 / 4 / 3 from `data/automations.ts`
- Add images to `public/images/automations/` and append cards in `data/automations.ts`
- Bot image: `public/images/agent/agent.jpg`
